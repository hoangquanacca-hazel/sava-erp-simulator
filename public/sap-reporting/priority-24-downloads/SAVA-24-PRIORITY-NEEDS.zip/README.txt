24 nhu cầu:23 view mới và1F1780 source-reference giữ nguyên trong thư viện cũ. 23XLSX/46CSV, không24 hồ sơ mới.
Dữ liệu tổng hợp SAVA; semantics tài liệu không chứng nhận tên/thứ tự cột export. Target releaseUNKNOWN.
Layout:tham số và dữ liệu riêng. Flat input:toàn bộ trường giữ RAW text. Fields:nguồn/quy tắc làm sạch/controls/IFRSdraft. CSV UTF8BOM/comma/CRLF là quy ước SAVA.
Baseline tách khỏi missing/locale/duplicate negative cases. Không cộng mọi dòng như sổ kế toán.
Nguồn chỉlink; không tái phân phối fileSAP công ty/ảnh/PDF. Không kết nối SAP/engine/API.
