SAVA DEMO — Mẫu dựng lại từ bố cục nguồn, dữ liệu tổng hợp. Không phải export SAP nguyên bản.

Mỗi biến thể: .layout.csv giữ dòng nhóm/tiêu đề/tổng; .flat.csv chỉ dòng chi tiết kèm thông tin nhóm; .xlsx gồm Layout, Flat input, Fields.

CSV UTF-8 BOM, dấu phân cột comma, chuỗi số mẫu theo de-DE, âm cuối, ngày DD.MM.YYYY. Khi nhập CSV vào Excel, đặt cột ID dạng Text để giữ số 0 đầu. XLSX đã lưu ID và chuỗi đầu vào dạng Text. Không cộng subtotal với detail; không cộng khác currency/UoM.

ME80FN là mẫu thay thế cho nhóm ME2N; F2217 là biến thể Fiori riêng. Các trường bị cắt/ẩn/technical name giữ chưa xác minh. Trường tài liệu mô tả ngoài ảnh nằm trong Fields, không ghép vào thứ tự export chưa có bằng chứng.

Nguồn bố cục và vị trí nhãn trong SOURCE-LAYOUT-MANIFEST.json. Không có ảnh/PDF hoặc giao dịch thật trong bộ này.
