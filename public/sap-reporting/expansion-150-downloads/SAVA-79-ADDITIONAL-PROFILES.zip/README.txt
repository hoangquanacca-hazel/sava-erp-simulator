SAVA — 79 hồ sơ bổ sung /158 CSV /79 XLSX. Tất cả là schema/layout đề xuất và dữ liệu tổng hợp, không phải SAP original export.
Layout giữ title/context/header/detail; Flat input chỉ gồm detail. Fields trong XLSX giải thích từng cột, provenance và quy tắc làm sạch.
Mỗi mẫu có4 ca: baseline tổng hợp, thiếu giá trị, locale châu Âu và khóa trùng cố ý. Không bỏ các ca lỗi như dữ liệu thật trước khi lưu exception/lineage.
RAW là chuỗi; XLSX giữ số0 đầu. CSV UTF8BOM/comma/CRLF do SAVA chọn, chưa xác minh delimiter/encoding SAP công ty.
Nguồn SAP chỉ dẫn link, không tái phân phối PDF/ảnh. Không có dữ liệu công ty và không kết nối SAP.
